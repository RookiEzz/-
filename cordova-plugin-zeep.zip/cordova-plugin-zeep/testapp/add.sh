cordova plugin add ../
