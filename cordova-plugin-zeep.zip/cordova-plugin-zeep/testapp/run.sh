sh ./remove.sh
sh ./add.sh
cordova run --archs=x86
